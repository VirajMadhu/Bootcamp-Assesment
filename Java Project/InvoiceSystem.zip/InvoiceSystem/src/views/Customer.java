package views;

import controllers.CustomerController;
import controllers.CustomerController;

import java.util.ArrayList;
import java.util.Scanner;

public class Customer {

    static char getAnswer(){
        Scanner sc = new Scanner(System.in);
        System.out.println("----- You are in Customer Menu -----");
        System.out.print("Do you want a do any other operation?(y/n) ");
        return sc.next().charAt(0);
    }

    public static void customerView(){
        do {
            switch (displayCustomer()){
                case 1:
                    addNewCustomer();
                    break;
                case 2:
                    updateCustomer();
                    break;
                case 3:
                    searchCustomer();
                    break;
                case 4:
                    viewAllCustomers();
                    break;
                case 5:
                    deleteCustomer();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        }while (getAnswer() == 'y' || getAnswer() == 'Y');
    }

    static void header(String headerText){
        System.out.println("**** Welcome to Invoice System | -'"+ headerText +"'- | ****");
        System.out.println("Please select correct option \n");
    }

    public static int displayCustomer(){
        header("CUSTOMER");
        System.out.println("1) Add new customer");
        System.out.println("2) Update Customer");
        System.out.println("3) Search Customer By Id");
        System.out.println("4) View All Customers");
        System.out.println("5) Delete Customer");
        System.out.println("6) Exit");

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your choice : ");
        return sc.nextInt();
    }

    public static void addNewCustomer(){
        header("ADD NEW CUSTOMER");

        //Take data from
        try{
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter customer ID : ");
            String cId = sc.next();
            System.out.print("Enter customer name : ");
            String cName = sc.next();
            System.out.print("Enter customer email : ");
            String cEmail = sc.next();
            System.out.print("Enter customer address : ");
            String cAddress = sc.next();
            System.out.print("Enter customer contact number : ");
            String cNumber = sc.next();
            System.out.print("Enter date of birth : ");
            String dob = sc.next();
            System.out.print("Enter gender : ");
            String gender = sc.next();

            int addC = CustomerController.addCustomer(new models.Customer( cId ,cName,cEmail,cAddress,cNumber,dob,gender));

            if (addC != 0){
                System.out.println("Customer Added Successfully!");
            }
            else {
                System.out.println("Something wrong!");
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
            //ex.printStackTrace();
        }finally {
            System.out.println("After All");
        }
    }

    public static void updateCustomer(){
        header("UPDATE CUSTOMER");

        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Customer ID to Update Data : ");
            String cId = sc.next();

            models.Customer cus = CustomerController.getCustomer(cId);
            //Display Data
            System.out.println("Customer name : "+ cus.getCustomerName());
            System.out.println("Customer email : "+cus.geteMail());
            System.out.println("Customer address : "+cus.getAddress());
            System.out.println("Contact Number : "+cus.getContactNo());
            System.out.println("Date of Birth : "+cus.getDateOfBirth());
            System.out.println("Gender :"+ cus.getGender());

            //Update data
            System.out.println("--- Enter New Data ---");
            System.out.print("Enter customer name : ");
            String cName = sc.next();
            System.out.print("Enter customer email : ");
            String cEmail = sc.next();
            System.out.print("Enter customer address : ");
            String cAddress = sc.next();
            System.out.print("Enter customer contact number : ");
            String cNumber = sc.next();
            System.out.print("Enter date of birth : ");
            String dob = sc.next();
            System.out.print("Enter gender : ");
            String gender = sc.next();

            int updateP = CustomerController.updateCustomer(cId,new models.Customer( cId ,cName,cEmail,cAddress,cNumber,dob,gender));

            if (updateP != 0){
                System.out.println("Customer Updated Successfully!");
            }
            else {
                System.out.println("Something wrong!");
            }
        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }

    public static void searchCustomer(){
        header("SEARCH CUSTOMER");

        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Customer ID to Search : ");
            String cId = sc.next();

            models.Customer cus = CustomerController.getCustomer(cId);
            //Display Data
            System.out.println("Customer name : "+ cus.getCustomerName());
            System.out.println("Customer email : "+cus.geteMail());
            System.out.println("Customer address : "+cus.getAddress());
            System.out.println("Contact Number : "+cus.getContactNo());
            System.out.println("Date of Birth : "+cus.getDateOfBirth());
            System.out.println("Gender :"+ cus.getGender());

        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }

    public static void viewAllCustomers(){
        header("ALL CUSTOMER");
        try {
            ArrayList<models.Customer> customerList = null;
            try {
                try {
                    customerList = CustomerController.getCustomers();
                } catch (Exception ex) {
                    System.out.println("Error => "+ex);
                }
            } catch (Exception ex) {
                System.out.println("Error => "+ex);
            }
            assert customerList != null;
            for (models.Customer customer : customerList) {
                Object[] rowData = {customer.getCustomerId(), customer.getCustomerName(), customer.geteMail(),customer.getAddress(),customer.getContactNo(),customer.getDateOfBirth(),customer.getGender()};
                for (Object rowDatum : rowData) {
                    System.out.format("%16s", rowDatum.toString());
                }
                System.out.println();
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
        }

    }

    public static void deleteCustomer(){
        header("DELETE CUSTOMER");

        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Customer ID to Delete : ");
            String cId = sc.next();

            System.out.print("Are you sure?(y/n)");
            char ans = sc.next().charAt(0);

            if (ans == 'y'){
                CustomerController.deleteCustomer(cId);
                System.out.println("Customer Deleted!");
            }

        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }
    }
}
