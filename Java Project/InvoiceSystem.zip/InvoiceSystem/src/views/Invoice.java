package views;


import controllers.InvoiceController;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Invoice {

    static char getAnswer(){
        Scanner sc = new Scanner(System.in);
        System.out.println("----- You are in Invoice Menu -----");
        System.out.print("Do you want a do any other operation?(y/n) ");
        return sc.next().charAt(0);
    }

    public static void invoiceView(){
        do {
            switch (displayInvoice()){
                case 1:
                    addNewInvoice();
                    break;
                case 2:
                    searchInvoice();
                    break;
                case 3:
                    viewAllInvoices();
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        }while (getAnswer() == 'y' || getAnswer() == 'Y');
    }

    static void header(String headerText){
        System.out.println("**** Welcome to Invoice System | -'"+ headerText +"'- | ****");
        System.out.println("Please select correct option \n");
    }

    public static int displayInvoice(){
        header("INVOICE");
        System.out.println("1) New Invoice");
        System.out.println("2) Search Invoice By Id");
        System.out.println("3) View All Invoices");
        System.out.println("4) Exit");

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your choice : ");
        return sc.nextInt();
    }

    public static void addNewInvoice(){
        header("ADD NEW INVOICE");

        try{
            Scanner sc = new Scanner(System.in);
            double totalPrice = 0;
            double discount = 0;

            LocalDate today = InvoiceController.getToday();
            String stringDate = today.toString();
            System.out.println("Date : " + stringDate);
            Date date =  new SimpleDateFormat("yyyy-MM-dd").parse(stringDate);

            System.out.print("Enter invoice name : ");
            String cName = sc.next();
            System.out.print("Enter product name : ");
            String pName = sc.next();
            System.out.print("Enter units per product : ");
            int units = sc.nextInt();
            System.out.print("Enter unit price : ");
            double unitPrice = sc.nextDouble();


            System.out.print("Do you want to add any discount?(y/n) : ");
            char ans = sc.next().charAt(0);
            
            if (ans == 'y'){
                System.out.print("Enter any discounts : ");
                discount = sc.nextDouble();
                
                totalPrice = (unitPrice * units)-discount;
                System.out.print("Total Price : "+totalPrice);
                
            }else {
                totalPrice = unitPrice * units;
                System.out.print("Total Price : "+totalPrice);
            }

            int addI = InvoiceController.addInvoice(new models.Invoice(date, cName, pName, units , unitPrice, totalPrice, discount));

            if (addI != 0){
                System.out.println("Invoice Added Successfully!");
            }
            else {
                System.out.println("Something wrong!");
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
            //ex.printStackTrace();
        }finally {
            System.out.println("After All");
        }
    }

    public static void searchInvoice(){
        header("SEARCH INVOICE");
        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Invoice ID to Search : ");
            String iId = sc.next();

            models.Invoice inv = InvoiceController.getInvoice(iId);
            //Display Data
            System.out.println("Invoice id : "+ inv.getInvoiceNumber());
            System.out.println("Invoice date : "+inv.getInvoiceDate());
            System.out.println("Customer Name : "+inv.getCustomerName());
            System.out.println("Product name : "+inv.getProductName());
            System.out.println("Units per product : "+inv.getUnitsPerProduct());
            System.out.println("Unit Price :"+ inv.getUnitPrice());
            System.out.println("Total Price :"+ inv.getTotalPrice());
            System.out.println("Discounts :"+ inv.getDiscount());
        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }

    public static void viewAllInvoices(){
        header("ALL INVOICE");

        try {
            ArrayList<models.Invoice> invoiceList = null;
            try {
                try {
                    invoiceList = InvoiceController.getInvoices();
                } catch (Exception ex) {
                    System.out.println("Error => "+ex);
                }
            } catch (Exception ex) {
                System.out.println("Error => "+ex);
            }
            assert invoiceList != null;
            for (models.Invoice invoice : invoiceList) {
                Object[] rowData = {invoice.getInvoiceNumber(), invoice.getInvoiceDate(), invoice.getCustomerName(),invoice.getProductName(),invoice.getUnitsPerProduct(),invoice.getUnitPrice(),invoice.getTotalPrice(), invoice.getDiscount()};
                for (Object rowDatum : rowData) {
                    System.out.format("%16s", rowDatum.toString());
                }
                System.out.println();
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
        }

    }

}
