package controllers;

import models.Customer;
import  connection.DataBaseConnection;
import models.Product;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CustomerController {
    //Convert String to date
    static Date stringToDate( String strDate) throws ParseException {
        return new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
    }

    //addCustomer
    public static int addCustomer(Customer cus) throws ClassNotFoundException, SQLException, ParseException {
        Connection con = DataBaseConnection.getConnection();

        String query = "INSERT INTO customers(customerId,customerName,eMail,address,contactNumber,dateOfBirth,gender) " +
                "VALUES('"+ cus.getCustomerId() +"','"+ cus.getCustomerName() +"','"+ cus.geteMail() +"','"+ cus.getAddress() +"','"+cus.getContactNo()+"','"+ stringToDate(cus.getDateOfBirth()) +"','"+ cus.getGender() +"')";

        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //customerUpdate
    public static int updateCustomer(String cusID, Customer cus) throws SQLException, ClassNotFoundException {
        Connection con = DataBaseConnection.getConnection();

        String query = "UPDATE customers SET(customerName='"+ cus.getCustomerId() +"',eMail='"+ cus.getCustomerId() +"',address='"+ cus.getCustomerId() +"',contactNumber='"+ cus.getCustomerId() +"',dateOfBirth='"+ cus.getCustomerId() +"',gender='"+ cus.getCustomerId() +"') WHERE customerId='"+ cusID +"'";
        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //customerDelete
    public static int deleteCustomer(String cusID) throws SQLException, ClassNotFoundException{
        Connection con = DataBaseConnection.getConnection();

        String query = "DELETE FROM customers WHERE customerId="+cusID;
        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //get customer
    public static Customer getCustomer(String cusID) throws ClassNotFoundException, SQLException {
        Connection con = DataBaseConnection.getConnection();

        Customer cus = null;

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM customers WHERE customerId="+cusID;
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()){
            String customerId = rs.getString("customerId");
            String customerName = rs.getString("customerName");
            String eMail = rs.getString("eMail");
            String address = rs.getString("address");
            String contactNumber = rs.getString("contactNumber");
            String dateOfBirth = rs.getString("dateOfBirth");
            String gender = rs.getString("gender");

            cus = new Customer(customerId, customerName, eMail, address, contactNumber, dateOfBirth, gender);
        }
        return cus;
    }

    //get customers
    public static ArrayList getCustomers() throws ClassNotFoundException, SQLException {
        Connection con = DataBaseConnection.getConnection();
        ArrayList customerArray = new ArrayList();

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM customers";
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()){
            String customerId = rs.getString("customerId");
            String customerName = rs.getString("customerName");
            String eMail = rs.getString("eMail");
            String address = rs.getString("address");
            String contactNumber = rs.getString("contactNumber");
            String dateOfBirth = rs.getString("dateOfBirth");
            String gender = rs.getString("gender");

            Customer cus  = new Customer(customerId, customerName, eMail, address, contactNumber, dateOfBirth, gender);
            customerArray.add(cus);
        }
        return customerArray;
    }
}
