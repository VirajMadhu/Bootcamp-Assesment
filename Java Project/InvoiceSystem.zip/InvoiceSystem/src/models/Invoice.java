package models;

import java.util.Date;

public class Invoice {
    private int invoiceNumber;
    private Date invoiceDate;
    private String customerName;
    private String productName;
    private int unitsPerProduct;
    private double unitPrice;
    private  double totalPrice;
    private  double discount;

    public Invoice( Date invoiceDate, String customerName, String productName, int unitsPerProduct, double unitPrice, double totalPrice, double discount) {
//        this.invoiceNumber = invoiceNumber;
        this.invoiceDate = invoiceDate;
        this.customerName = customerName;
        this.productName = productName;
        this.unitsPerProduct = unitsPerProduct;
        this.unitPrice = unitPrice;
        this.totalPrice = totalPrice;
        this.discount = discount;
    }

    public int getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(int invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getUnitsPerProduct() {
        return unitsPerProduct;
    }

    public void setUnitsPerProduct(int unitsPerProduct) {
        this.unitsPerProduct = unitsPerProduct;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
